import styles from "./page.module.css";

const page = async ({ params }) => {
  const { id } = await params;
  const response = await fetch(`https://fakestoreapi.com/products/${id}`);
  const product = await response.json();

  return (
    <div className={styles.wrapper}>
      <img className={styles.img} src={product.image} alt="productImage" />
      <div className={styles.description}>
        <p>Product collection</p>
        <h1>{product.title}</h1>
        <div className={styles.delivery}>
          <img
            className={styles.svg}
            src="../public/images/fast-delivery.svg"
          ></img>
          <p>Delivery from 3 weeks</p>
        </div>
        <h2>DESCRIPTION</h2>
        <p className={styles.desc}>{product.description}</p>
        <div className={styles.price}>
          <div>
            <h3 className={styles.regPrice}>Regular price</h3>
            <p>${product.price}</p>
          </div>
          <div className={styles.discount}>
            <h3 className={styles.regPrice}>Discount</h3>
            <p>10%</p>
          </div>
        </div>
        <div>
          <button className={styles.minus}>-</button>
          <span>1</span>
          <button className={styles.minus}>+</button>
        </div>
        <div className={styles.checkout}>
          <div className={styles.cartbuy}>
            <span>Add to cart</span>
          </div>
          <div className={styles.cartbuy}>
            <span>Buy now</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default page;
