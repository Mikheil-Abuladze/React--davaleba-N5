import styles from "./page.module.css";

const loading = () => {
  return <h1 className={styles.loading}>loading</h1>;
};

export default loading;
