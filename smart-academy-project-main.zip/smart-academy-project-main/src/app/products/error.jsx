"use client";
import styles from "./page.module.css";

function error() {
  return <div className={styles.error}>this is error</div>;
}

export default error;
